package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @PostMapping("/check_difference")
    public ResponseEntity<Response> checkDifference(@RequestBody Request request) {
        int difference = Math.abs(request.getFirstNumber() - request.getSecondNumber());
        String result;
        if (difference < 2) {
            result = String.valueOf(difference);
        } else {
            if (isSimple(difference)) {
                result = "SIMPLE";
            } else {
                result = "COMPOSITE";
            }
        }
        return ResponseEntity.ok(new Response(request.firstNumber, request.secondNumber, result));
    }

    /**
     * Метод проверки числа на простоту
     *
     * @param number Исходное число
     * @return true - если число простое, false - если нет
     */
    public boolean isSimple(int number) {
        for (int i = 2; i * i <= number; i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }
}
