package com.example.demo;

public class Response {
    public int firstNumber;
    public int secondNumber;
    public String result;

    public Response(int _firstNumber, int _secondNumber, String _result) {
        setFirstNumber(_firstNumber);
        setSecondNumber(_secondNumber);
        setResult(_result);
    }

    public void setFirstNumber(int firstNumber) {
        this.firstNumber = firstNumber;
    }

    public void setSecondNumber(int secondNumber) {
        this.secondNumber = secondNumber;
    }

    public void setResult(String result) {
        this.result = result;
    }

}
