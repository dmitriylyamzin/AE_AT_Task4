package com.example.demo;

public class Request {
    public int firstNumber;
    public int secondNumber;

    public Request(int _firstNumber, int _secondNumber) {
        setFirstNumber(_firstNumber);
        setSecondNumber(_secondNumber);
    }

    public void setFirstNumber(int firstNumber) {
        this.firstNumber = firstNumber;
    }

    public void setSecondNumber(int secondNumber) {
        this.secondNumber = secondNumber;
    }

    public int getFirstNumber() {
        return firstNumber;
    }

    public int getSecondNumber() {
        return secondNumber;
    }
}
